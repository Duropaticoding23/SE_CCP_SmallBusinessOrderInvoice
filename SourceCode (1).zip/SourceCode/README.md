# Small Business Order and Invoice Management System

CT-365 Software Engineering, Complex Computing Problem (Topic 7).
Node.js, Express and SQLite. Plain HTML, CSS and JavaScript for the interface.

## Setup

Requires Node.js 18 or later.

```
npm install
cp .env.example .env      # on Windows: copy .env.example .env
npm run seed              # creates database.db with sample data
npm start                 # opens on http://localhost:3000
```

If you skip `npm run seed`, the server creates the database on first start.

## Sample logins

| Username | Password   | Role        |
|----------|------------|-------------|
| admin    | Admin@123  | Admin       |
| sales1   | Staff@123  | Sales Staff |

Change these passwords before using the system for real.

## Tests

```
npm test
```

The suite runs 48 integration and unit tests against an in-memory database. Each test name starts with the test case ID from the SRS traceability matrix (for example TC-09).

## Folder guide

```
server.js, app.js     start-up and Express setup
db/                   schema.sql (tables and seed data), database helpers, seed script
middleware/           auth (JWT), requireRole, validate
routes/               auth, products, orders, invoices, users
services/             order.service (transactions), invoice.service, pdf.service, calc
public/               pages, css/style.css, js/app.js
tests/                api.test.js
```

## How stock stays correct

Placing an order runs inside one immediate SQLite transaction. For each line the server runs
`UPDATE products SET stock_qty = stock_qty - ? WHERE id = ? AND is_active = 1 AND stock_qty >= ?`.
If that changes no rows, the whole transaction rolls back. The table also has a `CHECK (stock_qty >= 0)` constraint as a second safeguard.
