const express = require('express');
const { AppError } = require('../errors');
const requireRole = require('../middleware/requireRole');
const v = require('../middleware/validate');

const COLUMNS = `id, sku, name, description, unit_price AS unitPrice, stock_qty AS stockQty, is_active AS isActive`;

function parseProduct(body) {
  return {
    sku: v.text(body.sku, 'SKU', { max: 30 }).toUpperCase(),
    name: v.text(body.name, 'Name', { max: 100 }),
    description: v.text(body.description, 'Description', { required: false, max: 300 }),
    unitPrice: v.price(body.unitPrice, 'Price'),
    stockQty: v.wholeNumber(body.stockQty, 'Stock', { min: 0, max: 1000000 }),
  };
}

module.exports = (db) => {
  const router = express.Router();

  router.get('/', (req, res, next) => {
    try {
      const q = v.likeTerm(req.query.q);
      const showAll = req.user.role === 'Admin' && req.query.includeInactive === '1';
      const rows = db
        .prepare(`SELECT ${COLUMNS} FROM products WHERE (? = 1 OR is_active = 1) AND (name LIKE ? ESCAPE '\\' OR sku LIKE ? ESCAPE '\\') ORDER BY name`)
        .all(showAll ? 1 : 0, q, q);
      res.json(rows);
    } catch (e) { next(e); }
  });

  router.post('/', requireRole('Admin'), (req, res, next) => {
    try {
      const p = parseProduct(req.body || {});
      if (db.prepare('SELECT 1 FROM products WHERE UPPER(sku) = ?').get(p.sku)) throw new AppError(409, `SKU ${p.sku} already exists.`);
      const r = db
        .prepare('INSERT INTO products (sku, name, description, unit_price, stock_qty) VALUES (?, ?, ?, ?, ?)')
        .run(p.sku, p.name, p.description, p.unitPrice, p.stockQty);
      res.status(201).json(db.prepare(`SELECT ${COLUMNS} FROM products WHERE id = ?`).get(r.lastInsertRowid));
    } catch (e) { next(e); }
  });

  router.put('/:id', requireRole('Admin'), (req, res, next) => {
    try {
      const id = Number(req.params.id);
      if (!db.prepare('SELECT 1 FROM products WHERE id = ?').get(id)) throw new AppError(404, 'Product not found.');
      const p = parseProduct(req.body || {});
      if (db.prepare('SELECT 1 FROM products WHERE UPPER(sku) = ? AND id <> ?').get(p.sku, id)) throw new AppError(409, `SKU ${p.sku} already exists.`);
      db.prepare(
        `UPDATE products SET sku = ?, name = ?, description = ?, unit_price = ?, stock_qty = ?, updated_at = datetime('now') WHERE id = ?`
      ).run(p.sku, p.name, p.description, p.unitPrice, p.stockQty, id);
      res.json(db.prepare(`SELECT ${COLUMNS} FROM products WHERE id = ?`).get(id));
    } catch (e) { next(e); }
  });

  router.patch('/:id/active', requireRole('Admin'), (req, res, next) => {
    try {
      const id = Number(req.params.id);
      if (!db.prepare('SELECT 1 FROM products WHERE id = ?').get(id)) throw new AppError(404, 'Product not found.');
      const active = v.bool((req.body || {}).isActive, 'isActive') ? 1 : 0;
      db.prepare("UPDATE products SET is_active = ?, updated_at = datetime('now') WHERE id = ?").run(active, id);
      res.json(db.prepare(`SELECT ${COLUMNS} FROM products WHERE id = ?`).get(id));
    } catch (e) { next(e); }
  });

  return router;
};
