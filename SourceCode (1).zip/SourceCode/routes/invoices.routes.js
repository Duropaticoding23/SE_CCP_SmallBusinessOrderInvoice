const express = require('express');
const invoices = require('../services/invoice.service');
const { writeInvoicePdf } = require('../services/pdf.service');
const { likeTerm } = require('../middleware/validate');

module.exports = (db) => {
  const router = express.Router();

  router.get('/', (req, res, next) => {
    try {
      const q = likeTerm(req.query.q);
      const rows = db
        .prepare(
          `SELECT i.id, i.invoice_no AS invoiceNo, i.issued_at AS issuedAt, i.total, i.payment_status AS paymentStatus,
                  o.order_no AS orderNo, o.status AS orderStatus, o.customer_name AS customerName
           FROM invoices i JOIN orders o ON o.id = i.order_id
           WHERE (? = 1 OR o.created_by = ?)
             AND (o.customer_name LIKE ? ESCAPE '\\' OR o.order_no LIKE ? ESCAPE '\\' OR i.invoice_no LIKE ? ESCAPE '\\')
           ORDER BY i.id DESC`
        )
        .all(req.user.role === 'Admin' ? 1 : 0, req.user.id, q, q, q);
      res.json(rows);
    } catch (e) { next(e); }
  });

  router.get('/:id', (req, res, next) => {
    try {
      res.json(invoices.getInvoice(db, Number(req.params.id), req.user));
    } catch (e) { next(e); }
  });

  router.get('/:id/pdf', (req, res, next) => {
    try {
      const invoice = invoices.getInvoice(db, Number(req.params.id), req.user);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${invoice.invoiceNo}.pdf"`);
      writeInvoicePdf(invoice, res);
    } catch (e) { next(e); }
  });

  router.patch('/:id/pay', (req, res, next) => {
    try {
      const invoice = invoices.getInvoice(db, Number(req.params.id), req.user);
      invoices.markPaid(db, invoice);
      res.json(invoices.getInvoice(db, invoice.id, req.user));
    } catch (e) { next(e); }
  });

  return router;
};
