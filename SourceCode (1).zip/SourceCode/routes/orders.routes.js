const express = require('express');
const { AppError } = require('../errors');
const requireRole = require('../middleware/requireRole');
const orders = require('../services/order.service');
const { likeTerm } = require('../middleware/validate');

module.exports = (db, cfg) => {
  const router = express.Router();

  const canSee = (user, order) => user.role === 'Admin' || order.createdBy === user.id;

  function loadOrder(id) {
    const order = db
      .prepare(
        `SELECT o.id, o.order_no AS orderNo, o.customer_name AS customerName, o.customer_phone AS customerPhone,
                o.customer_email AS customerEmail, o.created_by AS createdBy, o.status, o.subtotal,
                o.tax_rate AS taxRate, o.tax_amount AS taxAmount, o.total, o.created_at AS createdAt,
                i.id AS invoiceId, i.invoice_no AS invoiceNo, i.payment_status AS paymentStatus
         FROM orders o LEFT JOIN invoices i ON i.order_id = o.id WHERE o.id = ?`
      )
      .get(id);
    if (!order) throw new AppError(404, 'Order not found.');
    return order;
  }

  router.post('/', (req, res, next) => {
    try {
      const result = orders.placeOrder(db, cfg, req.user, req.body || {});
      res.status(201).json(result);
    } catch (e) { next(e); }
  });

  router.get('/', (req, res, next) => {
    try {
      const q = likeTerm(req.query.q);
      const rows = db
        .prepare(
          `SELECT o.id, o.order_no AS orderNo, o.customer_name AS customerName, o.status, o.total,
                  o.created_at AS createdAt, u.full_name AS createdByName,
                  i.id AS invoiceId, i.invoice_no AS invoiceNo, i.payment_status AS paymentStatus
           FROM orders o
           LEFT JOIN invoices i ON i.order_id = o.id
           JOIN users u ON u.id = o.created_by
           WHERE (? = 1 OR o.created_by = ?)
             AND (o.customer_name LIKE ? ESCAPE '\\' OR o.order_no LIKE ? ESCAPE '\\' OR i.invoice_no LIKE ? ESCAPE '\\')
           ORDER BY o.id DESC`
        )
        .all(req.user.role === 'Admin' ? 1 : 0, req.user.id, q, q, q);
      res.json(rows);
    } catch (e) { next(e); }
  });

  router.get('/:id', (req, res, next) => {
    try {
      const order = loadOrder(Number(req.params.id));
      if (!canSee(req.user, order)) throw new AppError(403, 'You do not have permission to view this order.');
      order.items = db
        .prepare(
          `SELECT p.sku, p.name, oi.quantity, oi.unit_price AS unitPrice, oi.line_total AS lineTotal
           FROM order_items oi JOIN products p ON p.id = oi.product_id WHERE oi.order_id = ? ORDER BY oi.id`
        )
        .all(order.id);
      res.json(order);
    } catch (e) { next(e); }
  });

  router.patch('/:id/deliver', (req, res, next) => {
    try {
      const order = loadOrder(Number(req.params.id));
      if (!canSee(req.user, order)) throw new AppError(403, 'You do not have permission to change this order.');
      orders.deliverOrder(db, order.id);
      res.json(loadOrder(order.id));
    } catch (e) { next(e); }
  });

  router.patch('/:id/cancel', requireRole('Admin'), (req, res, next) => {
    try {
      const id = Number(req.params.id);
      orders.cancelOrder(db, id);
      res.json(loadOrder(id));
    } catch (e) { next(e); }
  });

  return router;
};
