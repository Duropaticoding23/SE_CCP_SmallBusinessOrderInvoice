const express = require('express');
const bcrypt = require('bcryptjs');
const { AppError } = require('../errors');
const v = require('../middleware/validate');

const SELECT = `SELECT u.id, u.username, u.full_name AS fullName, u.is_active AS isActive, r.name AS role, u.created_at AS createdAt
                FROM users u JOIN roles r ON r.id = u.role_id`;

// Mounted behind requireRole('Admin') in app.js.
module.exports = (db) => {
  const router = express.Router();

  router.get('/', (req, res, next) => {
    try { res.json(db.prepare(`${SELECT} ORDER BY u.id`).all()); } catch (e) { next(e); }
  });

  router.post('/', (req, res, next) => {
    try {
      const b = req.body || {};
      const username = v.text(b.username, 'Username', { max: 40 });
      const fullName = v.text(b.fullName, 'Full name', { max: 100 });
      const password = typeof b.password === 'string' ? b.password : '';
      if (password.length < 8) throw new AppError(400, 'Password must have at least 8 characters.');
      const role = db.prepare('SELECT id FROM roles WHERE name = ?').get(b.role);
      if (!role) throw new AppError(400, 'Role must be Admin or Sales Staff.');
      if (db.prepare('SELECT 1 FROM users WHERE username = ?').get(username)) throw new AppError(409, `Username ${username} is already taken.`);
      const r = db
        .prepare('INSERT INTO users (username, password_hash, full_name, role_id) VALUES (?, ?, ?, ?)')
        .run(username, bcrypt.hashSync(password, 10), fullName, role.id);
      res.status(201).json(db.prepare(`${SELECT} WHERE u.id = ?`).get(r.lastInsertRowid));
    } catch (e) { next(e); }
  });

  router.patch('/:id/active', (req, res, next) => {
    try {
      const id = Number(req.params.id);
      if (!db.prepare('SELECT 1 FROM users WHERE id = ?').get(id)) throw new AppError(404, 'User not found.');
      const active = v.bool((req.body || {}).isActive, 'isActive') ? 1 : 0;
      if (id === req.user.id && !active) throw new AppError(409, 'You cannot deactivate your own account.');
      db.prepare('UPDATE users SET is_active = ? WHERE id = ?').run(active, id);
      res.json(db.prepare(`${SELECT} WHERE u.id = ?`).get(id));
    } catch (e) { next(e); }
  });

  return router;
};
