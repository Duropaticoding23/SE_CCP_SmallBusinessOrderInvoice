const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { AppError } = require('../errors');

module.exports = (db, cfg) => {
  const router = express.Router();

  router.post('/login', (req, res, next) => {
    try {
      const { username, password } = req.body || {};
      if (typeof username !== 'string' || typeof password !== 'string' || !username.trim() || !password) {
        throw new AppError(400, 'Enter a username and a password.');
      }
      const user = db
        .prepare(
          `SELECT u.id, u.username, u.password_hash AS hash, u.full_name AS fullName, u.is_active AS isActive, r.name AS role
           FROM users u JOIN roles r ON r.id = u.role_id WHERE u.username = ?`
        )
        .get(username.trim());
      // Same message for unknown user, wrong password and inactive user.
      if (!user || !user.isActive || !bcrypt.compareSync(password, user.hash)) {
        throw new AppError(401, 'Invalid username or password.');
      }
      const token = jwt.sign({ id: user.id, role: user.role }, cfg.jwtSecret, { expiresIn: '8h' });
      res.json({ token, user: { id: user.id, username: user.username, fullName: user.fullName, role: user.role } });
    } catch (e) {
      next(e);
    }
  });

  return router;
};
