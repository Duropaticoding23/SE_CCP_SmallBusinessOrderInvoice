// Shared helpers used by every page.
const TOKEN_KEY = 'oi_token';
const USER_KEY = 'oi_user';

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
const money = (n) => Number(n).toFixed(2);
const currentUser = () => JSON.parse(localStorage.getItem(USER_KEY) || 'null');

async function api(path, options = {}) {
  const headers = { 'Content-Type': 'application/json' };
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(`/api${path}`, { ...options, headers, body: options.body ? JSON.stringify(options.body) : undefined });
  if (res.status === 401 && !path.startsWith('/auth/')) {
    logout();
    return new Promise(() => {});
  }
  if (!res.ok) {
    let message = 'Request failed.';
    try { message = (await res.json()).error || message; } catch (e) { /* keep default */ }
    throw new Error(message);
  }
  return res.json();
}

function logout() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
  location.href = '/login.html';
}

function showMessage(kind, text) {
  const box = document.getElementById('message');
  if (!box) return;
  box.className = text ? `msg ${kind}` : '';
  box.textContent = text || '';
  if (text) box.scrollIntoView({ block: 'nearest' });
}

// Call at the top of each page. Redirects to login when there is no session
// and builds the navigation bar. Returns the logged-in user.
function startPage(active, adminOnly = false) {
  const user = currentUser();
  if (!user || !localStorage.getItem(TOKEN_KEY)) { location.href = '/login.html'; return null; }
  if (adminOnly && user.role !== 'Admin') { location.href = '/orders.html'; return null; }
  const links = [['products.html', 'Products'], ['new-order.html', 'New order'], ['orders.html', 'Orders']];
  if (user.role === 'Admin') links.push(['users.html', 'Users']);
  document.getElementById('nav').innerHTML =
    `<span class="brand">Order and Invoice System</span>` +
    links.map(([href, label]) => `<a href="${href}" class="${href.startsWith(active) ? 'active' : ''}">${label}</a>`).join('') +
    `<span class="who">${esc(user.fullName)} (${esc(user.role)})</span><button class="secondary small" id="logout">Log out</button>`;
  document.getElementById('logout').onclick = logout;
  return user;
}

const statusBadge = (s) =>
  `<span class="badge ${s === 'Cancelled' ? 'bad' : (s === 'Paid' || s === 'Delivered') ? 'good' : ''}">${esc(s)}</span>`;
