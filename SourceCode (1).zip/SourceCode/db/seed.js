require('dotenv').config();
const { openDb, initSchema } = require('./database');

const file = process.env.DB_PATH || 'database.db';
const db = openDb(file);
initSchema(db);
console.log(`Database created at ${file} with seed data.`);
db.close();
