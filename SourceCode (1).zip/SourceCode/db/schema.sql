-- ============================================================
-- Small Business Order and Invoice Management System
-- Database: SQLite 3 (foreign keys + transactions)
-- Run with:  sqlite3 database.db < schema.sql
-- ============================================================

PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS invoices;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS roles;

-- ------------------------------------------------------------
-- Roles
-- ------------------------------------------------------------
CREATE TABLE roles (
    id    INTEGER PRIMARY KEY AUTOINCREMENT,
    name  TEXT NOT NULL UNIQUE CHECK (name IN ('Admin', 'Sales Staff'))
);

-- ------------------------------------------------------------
-- Users
-- ------------------------------------------------------------
CREATE TABLE users (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    username       TEXT NOT NULL UNIQUE,
    password_hash  TEXT NOT NULL,                -- bcrypt hash, never plain text (NFR)
    full_name      TEXT NOT NULL,
    role_id        INTEGER NOT NULL,
    is_active      INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    created_at     TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

-- ------------------------------------------------------------
-- Products (inventory)
-- The CHECK on stock_qty is a second line of defence: even if
-- application code has a bug, the database refuses negative stock.
-- ------------------------------------------------------------
CREATE TABLE products (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    sku          TEXT NOT NULL UNIQUE,
    name         TEXT NOT NULL,
    description  TEXT,
    unit_price   REAL NOT NULL CHECK (unit_price >= 0),
    stock_qty    INTEGER NOT NULL DEFAULT 0 CHECK (stock_qty >= 0),
    is_active    INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    created_at   TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ------------------------------------------------------------
-- Orders
-- Customer details are stored on the order itself to keep the
-- prototype small. Tax rate is saved per order so old orders
-- keep their original totals if the rate changes later.
-- ------------------------------------------------------------
CREATE TABLE orders (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    order_no        TEXT NOT NULL UNIQUE,
    customer_name   TEXT NOT NULL,
    customer_phone  TEXT,
    customer_email  TEXT,
    created_by      INTEGER NOT NULL,
    status          TEXT NOT NULL DEFAULT 'Confirmed'
                    CHECK (status IN ('Pending', 'Confirmed', 'Delivered', 'Cancelled')),
    subtotal        REAL NOT NULL CHECK (subtotal >= 0),
    tax_rate        REAL NOT NULL CHECK (tax_rate >= 0 AND tax_rate <= 100),
    tax_amount      REAL NOT NULL CHECK (tax_amount >= 0),
    total           REAL NOT NULL CHECK (total >= 0),
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- ------------------------------------------------------------
-- Order items
-- unit_price is copied from the product at the time of sale so a
-- later price change does not alter past orders.
-- ------------------------------------------------------------
CREATE TABLE order_items (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id    INTEGER NOT NULL,
    product_id  INTEGER NOT NULL,
    quantity    INTEGER NOT NULL CHECK (quantity > 0),
    unit_price  REAL NOT NULL CHECK (unit_price >= 0),
    line_total  REAL NOT NULL CHECK (line_total >= 0),
    FOREIGN KEY (order_id)   REFERENCES orders(id)   ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- ------------------------------------------------------------
-- Invoices (one invoice per order)
-- ------------------------------------------------------------
CREATE TABLE invoices (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_no      TEXT NOT NULL UNIQUE,
    order_id        INTEGER NOT NULL UNIQUE,
    issued_at       TEXT NOT NULL DEFAULT (datetime('now')),
    subtotal        REAL NOT NULL CHECK (subtotal >= 0),
    tax_amount      REAL NOT NULL CHECK (tax_amount >= 0),
    total           REAL NOT NULL CHECK (total >= 0),
    payment_status  TEXT NOT NULL DEFAULT 'Unpaid'
                    CHECK (payment_status IN ('Unpaid', 'Paid')),
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- Indexes for common lookups
-- ------------------------------------------------------------
CREATE INDEX idx_products_name        ON products(name);
CREATE INDEX idx_orders_created_at    ON orders(created_at);
CREATE INDEX idx_orders_created_by    ON orders(created_by);
CREATE INDEX idx_order_items_order    ON order_items(order_id);
CREATE INDEX idx_order_items_product  ON order_items(product_id);

-- ============================================================
-- SEED DATA
-- ============================================================

INSERT INTO roles (name) VALUES ('Admin'), ('Sales Staff');

-- Passwords (bcrypt, cost 10):
--   admin  -> Admin@123
--   sales1 -> Staff@123
INSERT INTO users (username, password_hash, full_name, role_id) VALUES
('admin',  '$2b$10$qtFCyKfMAa8XiFg4d3CmYOPHrgFAMph2QnZQhPImQ3lLgIm6V9hiC', 'Store Owner',  (SELECT id FROM roles WHERE name = 'Admin')),
('sales1', '$2b$10$7CZ5F63W1pL2pFrNGSt1cejbBElMdj5moC933tB1NGo3DQMPYwU4.', 'Ayesha Khan',  (SELECT id FROM roles WHERE name = 'Sales Staff'));

INSERT INTO products (sku, name, description, unit_price, stock_qty) VALUES
('STN-001', 'A4 Paper Ream (500 sheets)', '80 gsm white copier paper',        1250.00, 120),
('STN-002', 'Ballpoint Pen Box (50)',     'Blue ink, medium tip',               900.00,  60),
('STN-003', 'Spiral Notebook',            '200 pages, ruled',                   220.00, 200),
('STN-004', 'Stapler Heavy Duty',         'Staples up to 50 sheets',            780.00,  25),
('STN-005', 'Permanent Marker Set (12)',  'Assorted colours',                   650.00,  40),
('STN-006', 'File Folder (Pack of 10)',   'Legal size, manila',                 480.00,  75),
('STN-007', 'Desk Calculator',            '12 digit, solar and battery',       1100.00,  15),
('STN-008', 'Whiteboard Eraser',          'Magnetic',                           150.00,   5);

-- One sample order with invoice so the UI has something to show.
-- Tax rate 18%:
--   10 x STN-003 (220.00) = 2200.00
--    2 x STN-004 (780.00) = 1560.00
--   subtotal 3760.00, tax 676.80, total 4436.80
-- The stock_qty values in the products seed above are the quantities
-- left after this order, so no stock adjustment is needed here.

INSERT INTO orders (order_no, customer_name, customer_phone, customer_email, created_by, status, subtotal, tax_rate, tax_amount, total)
VALUES ('ORD-0001', 'Bilal Traders', '0300-1234567', 'bilal@example.com',
        (SELECT id FROM users WHERE username = 'sales1'), 'Confirmed', 3760.00, 18, 676.80, 4436.80);

INSERT INTO order_items (order_id, product_id, quantity, unit_price, line_total) VALUES
((SELECT id FROM orders WHERE order_no = 'ORD-0001'), (SELECT id FROM products WHERE sku = 'STN-003'), 10, 220.00, 2200.00),
((SELECT id FROM orders WHERE order_no = 'ORD-0001'), (SELECT id FROM products WHERE sku = 'STN-004'),  2, 780.00, 1560.00);

INSERT INTO invoices (invoice_no, order_id, subtotal, tax_amount, total, payment_status)
VALUES ('INV-0001', (SELECT id FROM orders WHERE order_no = 'ORD-0001'), 3760.00, 676.80, 4436.80, 'Unpaid');
