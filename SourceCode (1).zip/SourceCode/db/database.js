const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');

function openDb(file) {
  const db = new Database(file);
  db.pragma('foreign_keys = ON');
  return db;
}

// Runs schema.sql (drops and recreates all tables, then loads the seed data).
function initSchema(db) {
  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  db.exec(sql);
}

function hasSchema(db) {
  const row = db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'users'").get();
  return Boolean(row);
}

module.exports = { openDb, initSchema, hasSchema };
