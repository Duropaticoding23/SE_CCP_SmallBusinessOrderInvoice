require('dotenv').config();
const { openDb, initSchema, hasSchema } = require('./db/database');
const { createApp } = require('./app');

const file = process.env.DB_PATH || 'database.db';
const db = openDb(file);
if (!hasSchema(db)) {
  initSchema(db);
  console.log('New database created with seed data.');
}
const port = Number(process.env.PORT || 3000);
createApp(db).listen(port, () => console.log(`Order and Invoice System running at http://localhost:${port}`));
