// Integration tests. Test names start with the test case ID reserved in the SRS (D2, Section 9).
const request = require('supertest');
const { openDb, initSchema } = require('../db/database');
const { createApp } = require('../app');
const { computeTotals } = require('../services/calc');

let db, app, adminToken, staffToken;

const login = async (username, password) =>
  request(app).post('/api/auth/login').send({ username, password });
const auth = (token) => ({ Authorization: `Bearer ${token}` });
const stock = (sku) => db.prepare('SELECT stock_qty AS s FROM products WHERE sku = ?').get(sku).s;
const productId = (sku) => db.prepare('SELECT id FROM products WHERE sku = ?').get(sku).id;
const order = (token, items, name = 'Test Customer') =>
  request(app).post('/api/orders').set(auth(token)).send({ customerName: name, items });

beforeEach(async () => {
  db = openDb(':memory:');
  initSchema(db);
  app = createApp(db, { jwtSecret: 'test-secret', taxRate: 18 });
  adminToken = (await login('admin', 'Admin@123')).body.token;
  staffToken = (await login('sales1', 'Staff@123')).body.token;
});
afterEach(() => db.close());

describe('Authentication and roles', () => {
  test('TC-01 valid login returns a token and the role', async () => {
    const res = await login('admin', 'Admin@123');
    expect(res.status).toBe(200);
    expect(res.body.token).toBeTruthy();
    expect(res.body.user.role).toBe('Admin');
  });

  test('TC-02 wrong password gives one generic message', async () => {
    const wrongPassword = await login('admin', 'nope');
    const unknownUser = await login('ghost', 'nope');
    expect(wrongPassword.status).toBe(401);
    expect(wrongPassword.body.error).toBe('Invalid username or password.');
    expect(unknownUser.body.error).toBe(wrongPassword.body.error);
  });

  test('TC-02b deactivated user cannot log in', async () => {
    db.prepare("UPDATE users SET is_active = 0 WHERE username = 'sales1'").run();
    expect((await login('sales1', 'Staff@123')).status).toBe(401);
  });

  test('TC-03 Sales Staff gets 403 on Admin-only routes', async () => {
    const users = await request(app).get('/api/users').set(auth(staffToken));
    const add = await request(app).post('/api/products').set(auth(staffToken)).send({});
    expect(users.status).toBe(403);
    expect(add.status).toBe(403);
  });

  test('TC-04 request without a token gets 401', async () => {
    expect((await request(app).get('/api/products')).status).toBe(401);
    expect((await request(app).get('/api/orders').set({ Authorization: 'Bearer junk' })).status).toBe(401);
  });
});

describe('Products', () => {
  const valid = { sku: 'NEW-001', name: 'Test Item', unitPrice: 99.5, stockQty: 10 };

  test('TC-05 Admin adds a product and it appears in the list', async () => {
    const res = await request(app).post('/api/products').set(auth(adminToken)).send(valid);
    expect(res.status).toBe(201);
    const list = await request(app).get('/api/products?q=NEW-001').set(auth(staffToken));
    expect(list.body).toHaveLength(1);
  });

  test('TC-05b Admin edits a product; a SKU clash and an unknown id are refused', async () => {
    const id = productId('STN-003');
    const ok = await request(app).put(`/api/products/${id}`).set(auth(adminToken)).send({ sku: 'STN-003', name: 'Notebook A5', unitPrice: 250, stockQty: 150 });
    expect(ok.status).toBe(200);
    expect(ok.body).toMatchObject({ name: 'Notebook A5', unitPrice: 250, stockQty: 150 });
    const clash = await request(app).put(`/api/products/${id}`).set(auth(adminToken)).send({ sku: 'stn-001', name: 'x', unitPrice: 1, stockQty: 1 });
    expect(clash.status).toBe(409);
    const missing = await request(app).put('/api/products/9999').set(auth(adminToken)).send({ sku: 'ZZ-1', name: 'x', unitPrice: 1, stockQty: 1 });
    expect(missing.status).toBe(404);
  });

  test('TC-06 duplicate SKU is rejected', async () => {
    const res = await request(app).post('/api/products').set(auth(adminToken)).send({ ...valid, sku: 'STN-001' });
    expect(res.status).toBe(409);
  });

  test.each([
    ['negative price', { unitPrice: -1 }],
    ['letters in price', { unitPrice: 'abc' }],
    ['three decimals', { unitPrice: 1.234 }],
    ['negative stock', { stockQty: -1 }],
    ['fractional stock', { stockQty: 1.5 }],
    ['missing name', { name: '' }],
  ])('TC-07 invalid product input is rejected: %s', async (_label, patch) => {
    const res = await request(app).post('/api/products').set(auth(adminToken)).send({ ...valid, ...patch });
    expect(res.status).toBe(400);
    expect(res.body.error).toBeTruthy();
  });

  test('TC-08 search by name and SKU, inactive products hidden from Sales Staff', async () => {
    const byName = await request(app).get('/api/products?q=notebook').set(auth(staffToken));
    expect(byName.body.map((p) => p.sku)).toEqual(['STN-003']);
    await request(app).patch(`/api/products/${productId('STN-003')}/active`).set(auth(adminToken)).send({ isActive: false });
    const afterStaff = await request(app).get('/api/products?q=notebook').set(auth(staffToken));
    const afterAdmin = await request(app).get('/api/products?q=notebook&includeInactive=1').set(auth(adminToken));
    expect(afterStaff.body).toHaveLength(0);
    expect(afterAdmin.body).toHaveLength(1);
  });
});

describe('Order placement (FR-03)', () => {
  test('TC-09 order total and 18% tax are correct and stock is reduced', async () => {
    const res = await order(staffToken, [{ productId: productId('STN-003'), quantity: 10 }, { productId: productId('STN-004'), quantity: 2 }]);
    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({ subtotal: 3760, taxAmount: 676.8, total: 4436.8 });
    expect(stock('STN-003')).toBe(190);
    expect(stock('STN-004')).toBe(23);
  });

  test('TC-10 empty order and missing customer are rejected', async () => {
    expect((await order(staffToken, [])).status).toBe(400);
    const noName = await request(app).post('/api/orders').set(auth(staffToken)).send({ customerName: ' ', items: [{ productId: 1, quantity: 1 }] });
    expect(noName.status).toBe(400);
  });

  test.each([[0], [-3], [1.5], ['x'], [10000]])('TC-10b invalid quantity %p is rejected', async (quantity) => {
    const res = await order(staffToken, [{ productId: productId('STN-001'), quantity }]);
    expect(res.status).toBe(400);
  });

  test('TC-11 quantity above stock is rejected and nothing is saved', async () => {
    const res = await order(staffToken, [{ productId: productId('STN-008'), quantity: 6 }]);
    expect(res.status).toBe(409);
    expect(res.body.error).toMatch(/Available: 5/);
    expect(stock('STN-008')).toBe(5);
    expect(db.prepare('SELECT COUNT(*) AS n FROM orders').get().n).toBe(1);
  });

  test('TC-12 quantity equal to stock is accepted and leaves stock at 0', async () => {
    const res = await order(staffToken, [{ productId: productId('STN-008'), quantity: 5 }]);
    expect(res.status).toBe(201);
    expect(stock('STN-008')).toBe(0);
  });

  test('TC-13 a failing line rolls back earlier lines in the same order', async () => {
    const res = await order(staffToken, [{ productId: productId('STN-001'), quantity: 5 }, { productId: productId('STN-008'), quantity: 99 }]);
    expect(res.status).toBe(409);
    expect(stock('STN-001')).toBe(120);
    expect(db.prepare('SELECT COUNT(*) AS n FROM order_items').get().n).toBe(2);
  });

  test('TC-14 duplicate lines are merged and an inactive product is refused', async () => {
    const id = productId('STN-002');
    const merged = await order(staffToken, [{ productId: id, quantity: 2 }, { productId: id, quantity: 3 }]);
    expect(merged.status).toBe(201);
    expect(stock('STN-002')).toBe(55);
    await request(app).patch(`/api/products/${id}/active`).set(auth(adminToken)).send({ isActive: false });
    expect((await order(staffToken, [{ productId: id, quantity: 1 }])).status).toBe(409);
  });

  test('TC-30 20 simultaneous orders for 10 units: exactly 10 succeed, stock ends at 0', async () => {
    db.prepare("UPDATE products SET stock_qty = 10 WHERE sku = 'STN-005'").run();
    const id = productId('STN-005');
    const results = await Promise.all(Array.from({ length: 20 }, () => order(staffToken, [{ productId: id, quantity: 1 }])));
    expect(results.filter((r) => r.status === 201)).toHaveLength(10);
    expect(results.filter((r) => r.status === 409)).toHaveLength(10);
    expect(stock('STN-005')).toBe(0);
  });
});

describe('Invoices', () => {
  const place = async (token = staffToken) =>
    (await order(token, [{ productId: productId('STN-003'), quantity: 2 }])).body;

  test('TC-15 each order has exactly one invoice with a unique number and matching amounts', async () => {
    const a = await place();
    const b = await place();
    expect(a.invoiceNo).not.toBe(b.invoiceNo);
    const inv = await request(app).get(`/api/invoices/${a.invoiceId}`).set(auth(staffToken));
    expect(inv.body).toMatchObject({ subtotal: 440, taxAmount: 79.2, total: 519.2, paymentStatus: 'Unpaid' });
    expect(inv.body.items).toHaveLength(1);
  });

  test('TC-16 invoice amounts equal order amounts', async () => {
    const r = await place();
    const o = await request(app).get(`/api/orders/${r.orderId}`).set(auth(staffToken));
    const inv = await request(app).get(`/api/invoices/${r.invoiceId}`).set(auth(staffToken));
    expect([inv.body.subtotal, inv.body.taxAmount, inv.body.total]).toEqual([o.body.subtotal, o.body.taxAmount, o.body.total]);
  });

  test('TC-17 PDF download returns a PDF with the invoice number in the file name', async () => {
    const r = await place();
    const res = await request(app).get(`/api/invoices/${r.invoiceId}/pdf`).set(auth(staffToken)).buffer(true).parse((resp, cb) => {
      const chunks = [];
      resp.on('data', (c) => chunks.push(c));
      resp.on('end', () => cb(null, Buffer.concat(chunks)));
    });
    expect(res.status).toBe(200);
    expect(res.headers['content-type']).toMatch(/application\/pdf/);
    expect(res.headers['content-disposition']).toContain(r.invoiceNo);
    expect(res.body.slice(0, 4).toString()).toBe('%PDF');
  });

  test('TC-18 PDF for a missing invoice gives 404; another staff member gets 403', async () => {
    expect((await request(app).get('/api/invoices/9999/pdf').set(auth(staffToken))).status).toBe(404);
    await request(app).post('/api/users').set(auth(adminToken)).send({ username: 'sales2', fullName: 'Second Staff', password: 'Password1', role: 'Sales Staff' });
    const other = (await login('sales2', 'Password1')).body.token;
    const r = await place(staffToken);
    expect((await request(app).get(`/api/invoices/${r.invoiceId}/pdf`).set(auth(other))).status).toBe(403);
    expect((await request(app).get(`/api/invoices/${r.invoiceId}/pdf`).set(auth(adminToken))).status).toBe(200);
  });

  test('TC-23 mark paid works once, and not for a cancelled order', async () => {
    const r = await place();
    expect((await request(app).patch(`/api/invoices/${r.invoiceId}/pay`).set(auth(staffToken))).body.paymentStatus).toBe('Paid');
    expect((await request(app).patch(`/api/invoices/${r.invoiceId}/pay`).set(auth(staffToken))).status).toBe(409);
    const r2 = await place();
    await request(app).patch(`/api/orders/${r2.orderId}/cancel`).set(auth(adminToken));
    expect((await request(app).patch(`/api/invoices/${r2.invoiceId}/pay`).set(auth(staffToken))).status).toBe(409);
  });
});

describe('Lists and status changes', () => {
  test('TC-19 lists are newest first and search works on customer, order and invoice number', async () => {
    await order(staffToken, [{ productId: productId('STN-003'), quantity: 1 }], 'Zubair Stores');
    const all = await request(app).get('/api/orders').set(auth(adminToken));
    expect(all.body[0].customerName).toBe('Zubair Stores');
    expect((await request(app).get('/api/orders?q=zubair').set(auth(adminToken))).body).toHaveLength(1);
    expect((await request(app).get('/api/orders?q=INV-0002').set(auth(adminToken))).body).toHaveLength(1);
    expect((await request(app).get('/api/invoices?q=ORD-0001').set(auth(adminToken))).body).toHaveLength(1);
    expect((await request(app).get('/api/orders?q=nothing-matches').set(auth(adminToken))).body).toEqual([]);
  });

  test('TC-20 Sales Staff see only their own orders', async () => {
    await request(app).post('/api/users').set(auth(adminToken)).send({ username: 'sales2', fullName: 'Second Staff', password: 'Password1', role: 'Sales Staff' });
    const other = (await login('sales2', 'Password1')).body.token;
    await order(other, [{ productId: productId('STN-003'), quantity: 1 }]);
    expect((await request(app).get('/api/orders').set(auth(other))).body).toHaveLength(1);
    expect((await request(app).get('/api/orders').set(auth(staffToken))).body).toHaveLength(1);
    expect((await request(app).get('/api/orders').set(auth(adminToken))).body).toHaveLength(2);
  });

  test('TC-21 Admin cancels an order: stock is returned and status changes', async () => {
    const r = (await order(staffToken, [{ productId: productId('STN-001'), quantity: 7 }])).body;
    expect(stock('STN-001')).toBe(113);
    const res = await request(app).patch(`/api/orders/${r.orderId}/cancel`).set(auth(adminToken));
    expect(res.body.status).toBe('Cancelled');
    expect(stock('STN-001')).toBe(120);
    expect((await request(app).patch(`/api/orders/${r.orderId}/cancel`).set(auth(adminToken))).status).toBe(409);
  });

  test('TC-22 Sales Staff cannot cancel; delivered orders cannot be cancelled', async () => {
    const r = (await order(staffToken, [{ productId: productId('STN-001'), quantity: 1 }])).body;
    expect((await request(app).patch(`/api/orders/${r.orderId}/cancel`).set(auth(staffToken))).status).toBe(403);
    expect((await request(app).patch(`/api/orders/${r.orderId}/deliver`).set(auth(staffToken))).body.status).toBe('Delivered');
    expect((await request(app).patch(`/api/orders/${r.orderId}/cancel`).set(auth(adminToken))).status).toBe(409);
  });
});

describe('User management', () => {
  const newUser = { username: 'sales3', fullName: 'Third Staff', password: 'Password1', role: 'Sales Staff' };

  test('TC-24 Admin creates a user who can then log in; password is stored hashed', async () => {
    expect((await request(app).post('/api/users').set(auth(adminToken)).send(newUser)).status).toBe(201);
    expect((await login('sales3', 'Password1')).status).toBe(200);
    const hash = db.prepare("SELECT password_hash AS h FROM users WHERE username = 'sales3'").get().h;
    expect(hash).not.toContain('Password1');
    expect(hash.startsWith('$2')).toBe(true);
  });

  test('TC-25 duplicate username, short password and bad role are rejected; Admin cannot deactivate self', async () => {
    await request(app).post('/api/users').set(auth(adminToken)).send(newUser);
    expect((await request(app).post('/api/users').set(auth(adminToken)).send(newUser)).status).toBe(409);
    expect((await request(app).post('/api/users').set(auth(adminToken)).send({ ...newUser, username: 'x1', password: 'short' })).status).toBe(400);
    expect((await request(app).post('/api/users').set(auth(adminToken)).send({ ...newUser, username: 'x2', role: 'Boss' })).status).toBe(400);
    const adminId = db.prepare("SELECT id FROM users WHERE username = 'admin'").get().id;
    expect((await request(app).patch(`/api/users/${adminId}/active`).set(auth(adminToken)).send({ isActive: false })).status).toBe(409);
  });

  test('TC-25b a deactivated user loses access immediately, even with a valid token', async () => {
    const staffId = db.prepare("SELECT id FROM users WHERE username = 'sales1'").get().id;
    await request(app).patch(`/api/users/${staffId}/active`).set(auth(adminToken)).send({ isActive: false });
    expect((await request(app).get('/api/products').set(auth(staffToken))).status).toBe(401);
  });
});

describe('Validation and calculation', () => {
  test('TC-26 malformed JSON gives a clear 400 with no stack trace', async () => {
    const res = await request(app).post('/api/auth/login').set('Content-Type', 'application/json').send('{bad json');
    expect(res.status).toBe(400);
    expect(JSON.stringify(res.body)).not.toMatch(/at .*\.js/);
  });

  test('TC-29 totals match hand-calculated values to two decimals', () => {
    const cases = [
      [[{ quantity: 1, unitPrice: 0.1 }, { quantity: 2, unitPrice: 0.2 }], 18, { subtotal: 0.5, taxAmount: 0.09, total: 0.59 }],
      [[{ quantity: 3, unitPrice: 19.99 }], 18, { subtotal: 59.97, taxAmount: 10.79, total: 70.76 }],
      [[{ quantity: 10, unitPrice: 220 }, { quantity: 2, unitPrice: 780 }], 18, { subtotal: 3760, taxAmount: 676.8, total: 4436.8 }],
      [[{ quantity: 1, unitPrice: 1250 }], 0, { subtotal: 1250, taxAmount: 0, total: 1250 }],
      [[{ quantity: 9999, unitPrice: 9999999.99 }], 18, { subtotal: 99989999900.01, taxAmount: 17998199982, total: 117988199882.01 }],
      [[{ quantity: 7, unitPrice: 33.33 }], 18, { subtotal: 233.31, taxAmount: 42, total: 275.31 }],
      [[{ quantity: 1, unitPrice: 0.01 }], 18, { subtotal: 0.01, taxAmount: 0, total: 0.01 }],
      [[{ quantity: 1, unitPrice: 0.03 }], 18, { subtotal: 0.03, taxAmount: 0.01, total: 0.04 }],
      [[{ quantity: 5, unitPrice: 650 }, { quantity: 1, unitPrice: 150 }], 18, { subtotal: 3400, taxAmount: 612, total: 4012 }],
      [[{ quantity: 2, unitPrice: 480 }, { quantity: 4, unitPrice: 900 }], 18, { subtotal: 4560, taxAmount: 820.8, total: 5380.8 }],
    ];
    for (const [lines, rate, expected] of cases) expect(computeTotals(lines, rate)).toEqual(expected);
  });
});

describe('Regression tests for defects found in exploratory testing', () => {
  test('TC-34 DEF-01 an oversized request body gets 413, not 500', async () => {
    const res = await request(app).post('/api/orders').set(auth(staffToken)).send({ customerName: 'x'.repeat(200000) });
    expect(res.status).toBe(413);
    expect(res.body.error).toBe('The request is too large.');
  });

  test('TC-35 DEF-02 isActive must be a real boolean; the string "false" is refused', async () => {
    const staffId = db.prepare("SELECT id FROM users WHERE username = 'sales1'").get().id;
    const bad = await request(app).patch(`/api/users/${staffId}/active`).set(auth(adminToken)).send({ isActive: 'false' });
    expect(bad.status).toBe(400);
    const badProduct = await request(app).patch(`/api/products/${productId('STN-001')}/active`).set(auth(adminToken)).send({ isActive: 'false' });
    expect(badProduct.status).toBe(400);
    const good = await request(app).patch(`/api/users/${staffId}/active`).set(auth(adminToken)).send({ isActive: false });
    expect(good.body.isActive).toBe(0);
  });

  test('TC-36 DEF-03 SKUs are stored in upper case and compared ignoring case', async () => {
    const lower = await request(app).post('/api/products').set(auth(adminToken)).send({ sku: ' stn-001 ', name: 'Copy', unitPrice: 1, stockQty: 1 });
    expect(lower.status).toBe(409);
    const fresh = await request(app).post('/api/products').set(auth(adminToken)).send({ sku: ' abc-9 ', name: 'Fresh', unitPrice: 1, stockQty: 1 });
    expect(fresh.status).toBe(201);
    expect(fresh.body.sku).toBe('ABC-9');
  });

  test('TC-37 DEF-04 % and _ typed in a search are matched literally', async () => {
    expect((await request(app).get('/api/products?q=%25').set(auth(staffToken))).body).toHaveLength(0);
    expect((await request(app).get('/api/products?q=_').set(auth(staffToken))).body).toHaveLength(0);
    expect((await request(app).get('/api/orders?q=%25').set(auth(adminToken))).body).toHaveLength(0);
    expect((await request(app).get('/api/invoices?q=%25').set(auth(adminToken))).body).toHaveLength(0);
    await request(app).post('/api/products').set(auth(adminToken)).send({ sku: 'PCT-1', name: '50% Off Pad', unitPrice: 5, stockQty: 2 });
    expect((await request(app).get('/api/products?q=50%25').set(auth(staffToken))).body).toHaveLength(1);
  });
});

describe('Non-functional checks', () => {
  const jwt = require('jsonwebtoken');
  const bcrypt = require('bcryptjs');

  test('TC-27 NFR-01 with 1,000 products and 5,000 orders, key calls answer in under 3 seconds', async () => {
    const addProduct = db.prepare('INSERT INTO products (sku, name, unit_price, stock_qty) VALUES (?, ?, ?, ?)');
    const addOrder = db.prepare("INSERT INTO orders (order_no, customer_name, created_by, status, subtotal, tax_rate, tax_amount, total) VALUES (?, ?, 1, 'Confirmed', 100, 18, 18, 118)");
    const addInvoice = db.prepare('INSERT INTO invoices (invoice_no, order_id, subtotal, tax_amount, total) VALUES (?, ?, 100, 18, 118)');
    db.transaction(() => {
      for (let i = 0; i < 1000; i++) addProduct.run(`BULK-${i}`, `Bulk product ${i}`, 10, 100);
      for (let i = 0; i < 5000; i++) {
        const r = addOrder.run(`BULK-ORD-${i}`, `Customer ${i}`);
        addInvoice.run(`BULK-INV-${i}`, r.lastInsertRowid);
      }
    })();
    const timed = async (fn) => { const t = Date.now(); const res = await fn(); return [res, Date.now() - t]; };
    const [products, t1] = await timed(() => request(app).get('/api/products').set(auth(staffToken)));
    const [orders, t2] = await timed(() => request(app).get('/api/orders?q=Customer 42').set(auth(adminToken)));
    const [placed, t3] = await timed(() => order(staffToken, [{ productId: productId('BULK-5'), quantity: 1 }]));
    expect(products.body.length).toBeGreaterThanOrEqual(1000);
    expect(orders.status).toBe(200);
    expect(placed.status).toBe(201);
    expect(Math.max(t1, t2, t3)).toBeLessThan(3000);
  });

  test('TC-28 NFR-02 hashes use cost 10 or more, expired tokens are refused, every route except login needs a token', async () => {
    const hash = db.prepare("SELECT password_hash AS h FROM users WHERE username = 'admin'").get().h;
    expect(bcrypt.getRounds(hash)).toBeGreaterThanOrEqual(10);
    const expired = jwt.sign({ id: 1, role: 'Admin' }, 'test-secret', { expiresIn: -10 });
    expect((await request(app).get('/api/products').set(auth(expired))).status).toBe(401);
    const exp = jwt.decode(adminToken).exp - jwt.decode(adminToken).iat;
    expect(exp).toBe(8 * 60 * 60);
    const routes = [
      ['get', '/api/config'], ['get', '/api/products'], ['post', '/api/products'], ['put', '/api/products/1'], ['patch', '/api/products/1/active'],
      ['post', '/api/orders'], ['get', '/api/orders'], ['get', '/api/orders/1'], ['patch', '/api/orders/1/deliver'], ['patch', '/api/orders/1/cancel'],
      ['get', '/api/invoices'], ['get', '/api/invoices/1'], ['get', '/api/invoices/1/pdf'], ['patch', '/api/invoices/1/pay'],
      ['get', '/api/users'], ['post', '/api/users'], ['patch', '/api/users/1/active'],
    ];
    for (const [method, url] of routes) expect((await request(app)[method](url)).status).toBe(401);
  });

  test('TC-33 NFR-07 an invoice PDF is returned in under 5 seconds', async () => {
    const t = Date.now();
    const res = await request(app).get('/api/invoices/1/pdf').set(auth(staffToken)).buffer(true).parse((resp, cb) => {
      const chunks = [];
      resp.on('data', (c) => chunks.push(c));
      resp.on('end', () => cb(null, Buffer.concat(chunks)));
    });
    expect(res.status).toBe(200);
    expect(Date.now() - t).toBeLessThan(5000);
  });
});
