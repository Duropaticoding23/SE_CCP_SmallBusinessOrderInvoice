const PDFDocument = require('pdfkit');

const money = (n) => Number(n).toFixed(2);

// Streams a simple itemized invoice to the response.
function writeInvoicePdf(invoice, res, businessName = 'Order and Invoice System') {
  const doc = new PDFDocument({ size: 'A4', margin: 50 });
  doc.pipe(res);

  doc.fontSize(20).text(businessName, { align: 'left' });
  doc.moveDown(0.3).fontSize(14).text(`INVOICE ${invoice.invoiceNo}`);
  doc.fontSize(10).fillColor('#444')
    .text(`Date: ${invoice.issuedAt}`)
    .text(`Order: ${invoice.orderNo}`)
    .text(`Status: ${invoice.paymentStatus}${invoice.orderStatus === 'Cancelled' ? ' (order cancelled)' : ''}`);
  doc.moveDown().fillColor('#000').fontSize(11).text('Bill to', { underline: true });
  doc.text(invoice.customerName);
  if (invoice.customerPhone) doc.text(invoice.customerPhone);
  if (invoice.customerEmail) doc.text(invoice.customerEmail);

  const col = { sku: 50, name: 120, qty: 330, price: 390, total: 470 };
  let y = doc.y + 20;
  doc.fontSize(10).font('Helvetica-Bold');
  doc.text('SKU', col.sku, y).text('Item', col.name, y).text('Qty', col.qty, y)
    .text('Unit price', col.price, y).text('Line total', col.total, y);
  doc.moveTo(50, y + 14).lineTo(545, y + 14).stroke();
  doc.font('Helvetica');
  y += 22;
  for (const it of invoice.items) {
    doc.text(it.sku, col.sku, y).text(it.name, col.name, y, { width: 200 }).text(String(it.quantity), col.qty, y)
      .text(money(it.unitPrice), col.price, y).text(money(it.lineTotal), col.total, y);
    y += 20;
  }
  doc.moveTo(50, y).lineTo(545, y).stroke();
  y += 10;
  doc.text('Subtotal', col.price, y).text(money(invoice.subtotal), col.total, y);
  y += 16;
  doc.text(`Tax (${invoice.taxRate}%)`, col.price, y).text(money(invoice.taxAmount), col.total, y);
  y += 16;
  doc.font('Helvetica-Bold').text('Total', col.price, y).text(money(invoice.total), col.total, y);
  doc.end();
}

module.exports = { writeInvoicePdf };
