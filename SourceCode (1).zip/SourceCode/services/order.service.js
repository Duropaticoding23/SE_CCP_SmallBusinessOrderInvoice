const { AppError } = require('../errors');
const v = require('../middleware/validate');
const { computeTotals, lineTotal } = require('./calc');

const pad = (n) => String(n).padStart(4, '0');

// Checks the request body and returns clean values. Duplicate products are merged.
function parseOrderInput(body) {
  const customerName = v.text(body.customerName, 'Customer name');
  const customerPhone = v.text(body.customerPhone, 'Phone', { required: false, max: 30 });
  const customerEmail = v.email(body.customerEmail);
  if (!Array.isArray(body.items) || body.items.length === 0) {
    throw new AppError(400, 'Add at least one product to the order.');
  }
  const merged = new Map();
  for (const item of body.items) {
    const productId = v.wholeNumber(item && item.productId, 'Product', { min: 1 });
    const quantity = v.wholeNumber(item && item.quantity, 'Quantity', { min: 1, max: v.MAX_QTY });
    merged.set(productId, (merged.get(productId) || 0) + quantity);
  }
  for (const qty of merged.values()) {
    if (qty > v.MAX_QTY) throw new AppError(400, `Quantity for one product must be at most ${v.MAX_QTY}.`);
  }
  return {
    customerName,
    customerPhone,
    customerEmail,
    items: [...merged].map(([productId, quantity]) => ({ productId, quantity })),
  };
}

// Places an order. Stock check, stock deduction, order, lines and invoice are
// saved in ONE immediate transaction: either everything is saved or nothing is.
function placeOrder(db, cfg, user, body) {
  const input = parseOrderInput(body);

  const deduct = db.prepare(
    `UPDATE products SET stock_qty = stock_qty - ?, updated_at = datetime('now')
     WHERE id = ? AND is_active = 1 AND stock_qty >= ?`
  );
  const getProduct = db.prepare('SELECT id, sku, name, unit_price, stock_qty, is_active FROM products WHERE id = ?');
  const insertOrder = db.prepare(
    `INSERT INTO orders (order_no, customer_name, customer_phone, customer_email, created_by, status,
                         subtotal, tax_rate, tax_amount, total)
     VALUES (?, ?, ?, ?, ?, 'Confirmed', ?, ?, ?, ?)`
  );
  const insertItem = db.prepare(
    'INSERT INTO order_items (order_id, product_id, quantity, unit_price, line_total) VALUES (?, ?, ?, ?, ?)'
  );
  const insertInvoice = db.prepare(
    `INSERT INTO invoices (invoice_no, order_id, subtotal, tax_amount, total) VALUES (?, ?, ?, ?, ?)`
  );
  const nextId = (table) => db.prepare(`SELECT COALESCE(MAX(id), 0) + 1 AS n FROM ${table}`).get().n;

  const run = db.transaction(() => {
    const lines = [];
    for (const { productId, quantity } of input.items) {
      const product = getProduct.get(productId);
      if (!product) throw new AppError(400, `Product ${productId} does not exist.`);
      if (!product.is_active) throw new AppError(409, `"${product.name}" is no longer available.`);
      const result = deduct.run(quantity, productId, quantity);
      if (result.changes === 0) {
        throw new AppError(409, `Not enough stock for "${product.name}". Available: ${product.stock_qty}.`, {
          productId,
          available: product.stock_qty,
        });
      }
      lines.push({ productId, quantity, unitPrice: product.unit_price });
    }
    const totals = computeTotals(lines, cfg.taxRate);
    const orderNo = `ORD-${pad(nextId('orders'))}`;
    const invoiceNo = `INV-${pad(nextId('invoices'))}`;
    const order = insertOrder.run(
      orderNo, input.customerName, input.customerPhone, input.customerEmail, user.id,
      totals.subtotal, cfg.taxRate, totals.taxAmount, totals.total
    );
    for (const l of lines) {
      insertItem.run(order.lastInsertRowid, l.productId, l.quantity, l.unitPrice, lineTotal(l.quantity, l.unitPrice));
    }
    const invoice = insertInvoice.run(invoiceNo, order.lastInsertRowid, totals.subtotal, totals.taxAmount, totals.total);
    return { orderId: Number(order.lastInsertRowid), invoiceId: Number(invoice.lastInsertRowid), orderNo, invoiceNo, ...totals };
  });

  return run.immediate();
}

// Cancels a Confirmed order and returns the stock, in one transaction.
function cancelOrder(db, orderId) {
  const run = db.transaction(() => {
    const order = db.prepare('SELECT id, status FROM orders WHERE id = ?').get(orderId);
    if (!order) throw new AppError(404, 'Order not found.');
    if (order.status !== 'Confirmed') throw new AppError(409, `Only Confirmed orders can be cancelled. This order is ${order.status}.`);
    const items = db.prepare('SELECT product_id, quantity FROM order_items WHERE order_id = ?').all(orderId);
    const restore = db.prepare("UPDATE products SET stock_qty = stock_qty + ?, updated_at = datetime('now') WHERE id = ?");
    for (const it of items) restore.run(it.quantity, it.product_id);
    db.prepare("UPDATE orders SET status = 'Cancelled' WHERE id = ?").run(orderId);
  });
  run.immediate();
}

function deliverOrder(db, orderId) {
  const order = db.prepare('SELECT id, status FROM orders WHERE id = ?').get(orderId);
  if (!order) throw new AppError(404, 'Order not found.');
  if (order.status !== 'Confirmed') throw new AppError(409, `Only Confirmed orders can be marked Delivered. This order is ${order.status}.`);
  db.prepare("UPDATE orders SET status = 'Delivered' WHERE id = ?").run(orderId);
}

module.exports = { placeOrder, cancelOrder, deliverOrder, parseOrderInput };
