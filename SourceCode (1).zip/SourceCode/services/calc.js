// All money maths is done in whole cents to avoid floating point drift.
const toCents = (value) => Math.round(Number(value) * 100);
const fromCents = (cents) => Math.round(cents) / 100;

function lineTotal(quantity, unitPrice) {
  return fromCents(quantity * toCents(unitPrice));
}

// lines: [{ quantity, unitPrice }], taxRate: percentage such as 18
function computeTotals(lines, taxRate) {
  const subtotalCents = lines.reduce((sum, l) => sum + l.quantity * toCents(l.unitPrice), 0);
  const taxCents = Math.round((subtotalCents * Number(taxRate)) / 100);
  return {
    subtotal: fromCents(subtotalCents),
    taxAmount: fromCents(taxCents),
    total: fromCents(subtotalCents + taxCents),
  };
}

module.exports = { toCents, fromCents, lineTotal, computeTotals };
