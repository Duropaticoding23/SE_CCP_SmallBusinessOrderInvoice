const { AppError } = require('../errors');

// Loads an invoice with its order and lines. Sales Staff may only see their own.
function getInvoice(db, id, user) {
  const invoice = db
    .prepare(
      `SELECT i.id, i.invoice_no AS invoiceNo, i.issued_at AS issuedAt, i.subtotal, i.tax_amount AS taxAmount,
              i.total, i.payment_status AS paymentStatus,
              o.id AS orderId, o.order_no AS orderNo, o.status AS orderStatus, o.customer_name AS customerName,
              o.customer_phone AS customerPhone, o.customer_email AS customerEmail, o.tax_rate AS taxRate,
              o.created_by AS createdBy
       FROM invoices i JOIN orders o ON o.id = i.order_id WHERE i.id = ?`
    )
    .get(id);
  if (!invoice) throw new AppError(404, 'Invoice not found.');
  if (user.role !== 'Admin' && invoice.createdBy !== user.id) {
    throw new AppError(403, 'You do not have permission to view this invoice.');
  }
  invoice.items = db
    .prepare(
      `SELECT p.sku, p.name, oi.quantity, oi.unit_price AS unitPrice, oi.line_total AS lineTotal
       FROM order_items oi JOIN products p ON p.id = oi.product_id WHERE oi.order_id = ? ORDER BY oi.id`
    )
    .all(invoice.orderId);
  return invoice;
}

function markPaid(db, invoice) {
  if (invoice.orderStatus === 'Cancelled') throw new AppError(409, 'An invoice for a cancelled order cannot be marked as paid.');
  if (invoice.paymentStatus === 'Paid') throw new AppError(409, 'This invoice is already paid.');
  db.prepare("UPDATE invoices SET payment_status = 'Paid' WHERE id = ?").run(invoice.id);
}

module.exports = { getInvoice, markPaid };
