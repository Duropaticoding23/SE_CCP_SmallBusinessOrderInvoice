const jwt = require('jsonwebtoken');
const { AppError } = require('../errors');

// Verifies the bearer token and loads the current user, so a user who has
// been deactivated loses access immediately even if their token is valid.
module.exports = (db, cfg) => (req, res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return next(new AppError(401, 'Please log in to continue.'));
  let payload;
  try {
    payload = jwt.verify(token, cfg.jwtSecret);
  } catch (e) {
    return next(new AppError(401, 'Your session has expired. Please log in again.'));
  }
  const user = db
    .prepare(
      `SELECT u.id, u.username, u.full_name AS fullName, u.is_active AS isActive, r.name AS role
       FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?`
    )
    .get(payload.id);
  if (!user || !user.isActive) return next(new AppError(401, 'This account is not active.'));
  req.user = user;
  next();
};
