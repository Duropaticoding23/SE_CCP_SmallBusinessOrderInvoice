const { AppError } = require('../errors');

const MAX_PRICE = 9999999.99;
const MAX_QTY = 9999;

function text(value, field, { required = true, max = 100 } = {}) {
  const v = typeof value === 'string' ? value.trim() : '';
  if (!v) {
    if (required) throw new AppError(400, `${field} is required.`);
    return null;
  }
  if (v.length > max) throw new AppError(400, `${field} must be at most ${max} characters.`);
  return v;
}

function price(value, field = 'Price') {
  const n = Number(value);
  if (value === '' || value === null || value === undefined || !Number.isFinite(n)) {
    throw new AppError(400, `${field} must be a number.`);
  }
  if (n < 0) throw new AppError(400, `${field} cannot be negative.`);
  if (n > MAX_PRICE) throw new AppError(400, `${field} cannot be more than ${MAX_PRICE}.`);
  if (Math.round(n * 100) / 100 !== n) throw new AppError(400, `${field} can have at most 2 decimal places.`);
  return n;
}

function wholeNumber(value, field, { min = 0, max = Number.MAX_SAFE_INTEGER } = {}) {
  const n = Number(value);
  if (value === '' || value === null || value === undefined || !Number.isInteger(n)) {
    throw new AppError(400, `${field} must be a whole number.`);
  }
  if (n < min) throw new AppError(400, `${field} must be at least ${min}.`);
  if (n > max) throw new AppError(400, `${field} must be at most ${max}.`);
  return n;
}

function email(value) {
  const v = text(value, 'Email', { required: false, max: 100 });
  if (v && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) throw new AppError(400, 'Email is not a valid address.');
  return v;
}

function bool(value, field) {
  if (typeof value !== 'boolean') throw new AppError(400, `${field} must be true or false.`);
  return value;
}

// Builds a LIKE pattern in which % and _ typed by the user are matched literally.
// Use with: LIKE ? ESCAPE '\\'
function likeTerm(value) {
  const t = String(value || '').trim().replace(/[\\%_]/g, '\\$&');
  return `%${t}%`;
}

module.exports = { text, price, wholeNumber, email, bool, likeTerm, MAX_PRICE, MAX_QTY };
