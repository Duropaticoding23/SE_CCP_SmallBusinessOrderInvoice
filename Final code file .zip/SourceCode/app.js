const express = require('express');
const path = require('path');
const { AppError } = require('./errors');
const authMiddleware = require('./middleware/auth');
const requireRole = require('./middleware/requireRole');

function createApp(db, overrides = {}) {
  const cfg = {
    jwtSecret: process.env.JWT_SECRET || 'dev-secret-change-me',
    taxRate: Number(process.env.TAX_RATE || 18),
    ...overrides,
  };
  const app = express();
  app.use(express.json({ limit: '100kb' }));

  const auth = authMiddleware(db, cfg);
  app.use('/api/auth', require('./routes/auth.routes')(db, cfg));
  app.get('/api/config', auth, (req, res) => res.json({ taxRate: cfg.taxRate }));
  app.use('/api/dashboard', auth, require('./routes/dashboard.routes')(db));
  app.use('/api/products', auth, require('./routes/products.routes')(db));
  app.use('/api/orders', auth, require('./routes/orders.routes')(db, cfg));
  app.use('/api/invoices', auth, require('./routes/invoices.routes')(db));
  app.use('/api/users', auth, requireRole('Admin'), require('./routes/users.routes')(db));

  app.use('/api', (req, res, next) => next(new AppError(404, 'Route not found.')));
  app.use(express.static(path.join(__dirname, 'public')));

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err instanceof AppError) return res.status(err.status).json({ error: err.message, details: err.details });
    if (err.type === 'entity.too.large') return res.status(413).json({ error: 'The request is too large.' });
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'The request body is not valid JSON.' });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong on the server. Please try again.' });
  });
  return app;
}

module.exports = { createApp };
