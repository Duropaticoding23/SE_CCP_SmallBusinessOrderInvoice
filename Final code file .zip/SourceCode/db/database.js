// Uses the SQLite that is built into Node.js (node:sqlite), so nothing has to be
// compiled and no extra database package is needed. Requires Node.js 22.13 or newer.
const fs = require('fs');
const path = require('path');

// process.getBuiltinModule also works inside Jest, where require('node:sqlite') can fail.
const { DatabaseSync } = process.getBuiltinModule('node:sqlite');

// SQLite cannot bind NaN or undefined, so they are stored as NULL.
const clean = (args) => args.map((a) => (a === undefined || (typeof a === 'number' && Number.isNaN(a)) ? null : a));

function wrap(db) {
  const rawPrepare = db.prepare.bind(db);

  db.prepare = (sql) => {
    const stmt = rawPrepare(sql);
    return {
      get: (...a) => stmt.get(...clean(a)),
      all: (...a) => stmt.all(...clean(a)),
      run: (...a) => {
        const r = stmt.run(...clean(a));
        return { changes: Number(r.changes), lastInsertRowid: Number(r.lastInsertRowid) };
      },
    };
  };

  // db.transaction(fn) returns a function that runs fn inside BEGIN ... COMMIT,
  // and rolls everything back if fn throws. Use .immediate(...) to take the
  // write lock at the start, which is what the order service does.
  db.transaction = (fn) => {
    const make = (begin) => (...args) => {
      db.exec(begin);
      try {
        const result = fn(...args);
        db.exec('COMMIT');
        return result;
      } catch (err) {
        try { db.exec('ROLLBACK'); } catch (e) { /* nothing to roll back */ }
        throw err;
      }
    };
    const run = make('BEGIN');
    run.immediate = make('BEGIN IMMEDIATE');
    return run;
  };

  return db;
}

function openDb(file) {
  const db = new DatabaseSync(file);
  db.exec('PRAGMA foreign_keys = ON');
  return wrap(db);
}

// Runs schema.sql (drops and recreates all tables, then loads the seed data).
function initSchema(db) {
  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  db.exec(sql);
}

function hasSchema(db) {
  const row = db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'users'").get();
  return Boolean(row);
}

module.exports = { openDb, initSchema, hasSchema };
