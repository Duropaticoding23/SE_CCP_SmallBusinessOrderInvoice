const express = require('express');

const round2 = (n) => Math.round(Number(n) * 100) / 100;

// Summary numbers for the dashboard. Admin sees everything; Sales Staff see
// the figures for their own orders (stock figures are the same for everyone).
module.exports = (db) => {
  const router = express.Router();

  router.get('/', (req, res, next) => {
    try {
      const all = req.user.role === 'Admin' ? 1 : 0;
      const uid = req.user.id;
      const scope = '(? = 1 OR o.created_by = ?)';
      const one = (sql, ...params) => db.prepare(sql).get(...params);

      const today = one(
        `SELECT COALESCE(SUM(o.total), 0) AS sales, COUNT(*) AS orders FROM orders o
         WHERE o.status <> 'Cancelled' AND date(o.created_at) = date('now') AND ${scope}`, all, uid);
      const month = one(
        `SELECT COALESCE(SUM(o.total), 0) AS sales, COUNT(*) AS orders FROM orders o
         WHERE o.status <> 'Cancelled' AND strftime('%Y-%m', o.created_at) = strftime('%Y-%m', 'now') AND ${scope}`, all, uid);
      const unpaid = one(
        `SELECT COUNT(*) AS count, COALESCE(SUM(i.total), 0) AS total FROM invoices i JOIN orders o ON o.id = i.order_id
         WHERE i.payment_status = 'Unpaid' AND o.status <> 'Cancelled' AND ${scope}`, all, uid);
      const productCount = one('SELECT COUNT(*) AS n FROM products WHERE is_active = 1').n;
      const lowStockCount = one('SELECT COUNT(*) AS n FROM products WHERE is_active = 1 AND stock_qty <= 5').n;
      const lowStock = db
        .prepare('SELECT id, sku, name, stock_qty AS stockQty FROM products WHERE is_active = 1 AND stock_qty <= 5 ORDER BY stock_qty, name LIMIT 8')
        .all();
      const recentOrders = db
        .prepare(
          `SELECT o.id, o.order_no AS orderNo, o.customer_name AS customerName, o.status, o.total, o.created_at AS createdAt,
                  i.id AS invoiceId, i.invoice_no AS invoiceNo, i.payment_status AS paymentStatus
           FROM orders o LEFT JOIN invoices i ON i.order_id = o.id WHERE ${scope} ORDER BY o.id DESC LIMIT 5`)
        .all(all, uid);
      const topProducts = db
        .prepare(
          `SELECT p.name AS name, SUM(oi.quantity) AS units, SUM(oi.line_total) AS revenue
           FROM order_items oi JOIN orders o ON o.id = oi.order_id JOIN products p ON p.id = oi.product_id
           WHERE o.status <> 'Cancelled' AND ${scope} GROUP BY p.id ORDER BY units DESC, p.name LIMIT 5`)
        .all(all, uid);
      const dailyRows = db
        .prepare(
          `SELECT date(o.created_at) AS day, SUM(o.total) AS total FROM orders o
           WHERE o.status <> 'Cancelled' AND date(o.created_at) >= date('now', '-6 days') AND ${scope} GROUP BY day`)
        .all(all, uid);

      // The last seven days (UTC, the same clock SQLite uses), with zero for days without sales.
      const byDay = new Map(dailyRows.map((r) => [r.day, r.total]));
      const salesByDay = [];
      for (let i = 6; i >= 0; i--) {
        const day = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
        salesByDay.push({ day, total: round2(byDay.get(day) || 0) });
      }

      res.json({
        scope: all ? 'all' : 'own',
        today: { sales: round2(today.sales), orders: today.orders },
        month: { sales: round2(month.sales), orders: month.orders },
        unpaid: { count: unpaid.count, total: round2(unpaid.total) },
        productCount,
        lowStockCount,
        lowStock,
        recentOrders: recentOrders.map((o) => ({ ...o })),
        topProducts: topProducts.map((p) => ({ name: p.name, units: p.units, revenue: round2(p.revenue) })),
        salesByDay,
      });
    } catch (e) { next(e); }
  });

  return router;
};
