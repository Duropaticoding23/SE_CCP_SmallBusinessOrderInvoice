// Shared helpers used by every page.
const TOKEN_KEY = 'oi_token';
const USER_KEY = 'oi_user';

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
const money = (n) => Number(n).toFixed(2);
const currentUser = () => JSON.parse(localStorage.getItem(USER_KEY) || 'null');

async function api(path, options = {}) {
  const headers = { 'Content-Type': 'application/json' };
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(`/api${path}`, { ...options, headers, body: options.body ? JSON.stringify(options.body) : undefined });
  if (res.status === 401 && !path.startsWith('/auth/')) {
    logout();
    return new Promise(() => {});
  }
  if (!res.ok) {
    let message = 'Request failed.';
    try { message = (await res.json()).error || message; } catch (e) { /* keep default */ }
    throw new Error(message);
  }
  return res.json();
}

function logout() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
  location.href = '/login.html';
}

function showMessage(kind, text) {
  const box = document.getElementById('message');
  if (!box) return;
  box.className = text ? `msg ${kind}` : '';
  box.textContent = text || '';
  if (text) box.scrollIntoView({ block: 'nearest' });
}

const ICONS = {
  dashboard: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
  box: '<path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/>',
  plus: '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><path d="M16 4.5a3.5 3.5 0 010 7M18.5 14.5c1.8.7 3 2.5 3 5.5"/>',
};
const icon = (name) =>
  `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name]}</svg>`;

// Call at the top of each page. Redirects to login when there is no session
// and builds the sidebar. Returns the logged-in user.
function startPage(active, adminOnly = false) {
  const user = currentUser();
  if (!user || !localStorage.getItem(TOKEN_KEY)) { location.href = '/login.html'; return null; }
  if (adminOnly && user.role !== 'Admin') { location.href = '/dashboard.html'; return null; }
  document.body.classList.add('app');
  const links = [
    ['dashboard.html', 'Dashboard', 'dashboard'],
    ['products.html', 'Products', 'box'],
    ['new-order.html', 'New order', 'plus'],
    ['orders.html', 'Orders and invoices', 'list'],
  ];
  if (user.role === 'Admin') links.push(['users.html', 'Users', 'users']);
  document.getElementById('nav').innerHTML =
    `<div class="brand"><span class="logo">OI</span><span>Order and Invoice</span></div>` +
    links.map(([href, label, ic]) => `<a href="${href}" class="${href.startsWith(active) ? 'active' : ''}">${icon(ic)}<span>${label}</span></a>`).join('') +
    `<div class="who"><strong>${esc(user.fullName)}</strong>${esc(user.role)}<button class="secondary small" id="logout">Log out</button></div>`;
  document.getElementById('logout').onclick = logout;
  return user;
}

const statusBadge = (s) =>
  `<span class="badge ${s === 'Cancelled' ? 'bad' : (s === 'Paid' || s === 'Delivered') ? 'good' : ''}">${esc(s)}</span>`;
